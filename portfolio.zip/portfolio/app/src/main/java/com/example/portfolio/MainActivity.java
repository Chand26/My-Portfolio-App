package com.example.portfolio;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        Button contactButton = findViewById(R.id.contact_button);


        contactButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String emailId = "iamchandanass@gmail.com";
                String instagramId = "@_chandh_";
                String contactNumber = "+91 9743269236";


                Intent intent = new Intent(MainActivity.this, DisplayDetailsActivity.class);
                intent.putExtra("emailId", emailId);
                intent.putExtra("instagramId", instagramId);
                intent.putExtra("contactNumber", contactNumber);
                startActivity(intent); // Start the new activity
            }
        });
    }
}
