package com.example.portfolio;

import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class DisplayDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_details);


        String emailId=getIntent().getStringExtra("emailId");
        String instagramId = getIntent().getStringExtra("instagramId");
        String contactNumber = getIntent().getStringExtra("contactNumber");


        TextView headerTextView = findViewById(R.id.header_text);
        headerTextView.setText("Ping Me");


        TextView emailIdTextView = findViewById(R.id.email_display);
        TextView instagramTextView = findViewById(R.id.instagram_display);
        TextView contactTextView = findViewById(R.id.contact_display);

        emailIdTextView.setText("Email: " + emailId);
        instagramTextView.setText("Instagram: " + instagramId);
        contactTextView.setText("Contact: " + contactNumber);

    }
}
